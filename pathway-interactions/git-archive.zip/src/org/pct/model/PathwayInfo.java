package org.pct.model;

public interface PathwayInfo {
	public String getId();
	public String getName();
}
